import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
import joblib
import json

class WaterDemandPredictor:
    def __init__(self):
        self.model = RandomForestRegressor(
            n_estimators=200,
            max_depth=20,
            min_samples_split=5,
            random_state=42,
            n_jobs=-1
        )
        self.features = [
            'DayOfYear', 'Temperature_C', 'Rainfall_mm', 'Humidity_%',
            'SoilMoisture_%', 'WindSpeed_kmph', 'PopulationDensity',
            'Season', 'PreviousDayUsage_L'
        ]
        self.target = 'PredictedDemand_L'
        self.cat_features = ['Season']
        self.num_features = [f for f in self.features if f not in self.cat_features]
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('num', 'passthrough', self.num_features),
                ('cat', OneHotEncoder(handle_unknown='ignore'), self.cat_features)
            ])
        self.pipeline = Pipeline([
            ('preprocessor', self.preprocessor),
            ('regressor', self.model)
        ])

    def load_data(self, filepath):
        df = pd.read_csv(filepath)
        df = df.dropna()
        return df

    def train_evaluate(self, test_size=0.2):
        df = self.load_data('Water_Demand_Dataset.csv')
        X = df[self.features]
        y = df[self.target]
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42
        )
        
        self.pipeline.fit(X_train, y_train)
        
        # Get feature importances
        feature_importances = self.model.feature_importances_
        ohe_feature_names = list(
            self.preprocessor.named_transformers_['cat']
            .get_feature_names_out(self.cat_features)
        )
        self.feature_importance = dict(zip(
            self.num_features + ohe_feature_names,
            feature_importances
        ))
        
        # Evaluate
        y_pred = self.pipeline.predict(X_test)
        metrics = {
            'mae': mean_absolute_error(y_test, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'r2': r2_score(y_test, y_pred),
            'feature_importances': self.feature_importance
        }
        
        return metrics
    
    def save_model(self, model_path='water_demand_model.pkl'):
        joblib.dump(self.pipeline, model_path)
        with open('feature_importance.json', 'w') as f:
            json.dump(self.feature_importance, f, indent=4)
        print(f"Model saved to {model_path}")

def main():
    predictor = WaterDemandPredictor()
    
    print("Training and evaluating model...")
    metrics = predictor.train_evaluate()
    
    print("\nModel Evaluation:")
    print(f"MAE: {metrics['mae']:.2f}")
    print(f"RMSE: {metrics['rmse']:.2f}")
    print(f"R²: {metrics['r2']:.4f}")
    
    print("\nFeature Importances:")
    for f, i in sorted(metrics['feature_importances'].items(), 
                      key=lambda x: x[1], reverse=True):
        print(f"{f}: {i:.4f}")
    
    predictor.save_model()

if __name__ == "__main__":
    main()
