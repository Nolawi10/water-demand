import pandas as pd
import numpy as np
import random

# Seed for reproducibility
np.random.seed(42)

def generate_season(day):
    if 80 <= day < 172:
        return "Spring"
    elif 172 <= day < 264:
        return "Summer"
    elif 264 <= day < 355:
        return "Autumn"
    else:
        return "Winter"

def generate_data(n=10000):
    data = []
    for _ in range(n):
        day_of_year = random.randint(1, 365)
        season = generate_season(day_of_year)

        # Generate temperature based on season
        if season == "Winter":
            temp = round(np.random.normal(10, 3), 1)
        elif season == "Spring":
            temp = round(np.random.normal(20, 4), 1)
        elif season == "Summer":
            temp = round(np.random.normal(30, 5), 1)
        else:  # Autumn
            temp = round(np.random.normal(18, 3), 1)

        # Rainfall inversely related to temp
        if temp > 35:
            rainfall = round(np.random.normal(0, 2), 1)
        elif temp > 30:
            rainfall = round(np.random.normal(1, 4), 1)
        elif temp > 20:
            rainfall = round(np.random.normal(10, 10), 1)
        else:
            rainfall = round(np.random.normal(20, 15), 1)
        rainfall = max(0, rainfall)

        # Humidity logic
        humidity = np.clip(100 - temp + rainfall * 0.2 + np.random.normal(0, 5), 10, 100)

        # Soil moisture influenced by rain and humidity
        soil_moisture = np.clip(rainfall * 1.5 + humidity * 0.3 + np.random.normal(0, 5), 0, 100)

        # Wind speed variation
        wind_speed = round(np.random.normal(10, 5), 1)
        wind_speed = max(0, wind_speed)

        # Population density
        population_density = np.random.randint(50, 5000)

        # Previous day usage in liters (based on population and season)
        base_usage = population_density * np.random.uniform(0.3, 0.6)
        if season == "Summer":
            base_usage *= 1.1
        elif season == "Winter":
            base_usage *= 0.9
        prev_day_usage = round(base_usage + np.random.normal(0, 100))

        # Predicted demand model (simplified logic for realism)
        predicted_demand = prev_day_usage + (temp * 2.5 - rainfall * 1.2 + humidity * 0.5 - soil_moisture * 0.3 + wind_speed * 1.5)
        predicted_demand += np.random.normal(0, 50)
        predicted_demand = max(0, round(predicted_demand, 1))

        data.append([
            day_of_year, temp, rainfall, humidity, soil_moisture,
            wind_speed, population_density, season, prev_day_usage,
            predicted_demand
        ])

    columns = [
        "DayOfYear", "Temperature_C", "Rainfall_mm", "Humidity_%",
        "SoilMoisture_%", "WindSpeed_kmph", "PopulationDensity",
        "Season", "PreviousDayUsage_L", "PredictedDemand_L"
    ]

    df = pd.DataFrame(data, columns=columns)
    return df

# Generate and save to CSV
df = generate_data(10000)
df.to_csv("/mnt/data/Realistic_Water_Demand_Dataset.csv", index=False)
